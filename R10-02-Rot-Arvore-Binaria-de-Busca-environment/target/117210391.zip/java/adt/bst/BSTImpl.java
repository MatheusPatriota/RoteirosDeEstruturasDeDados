package adt.bst;

public class BSTImpl<T extends Comparable<T>> implements BST<T> {

   protected BSTNode<T> root;

   public BSTImpl() {
      root = new BSTNode<T>();
   }

   public BSTNode<T> getRoot() {
      return this.root;
   }

   @Override
   public boolean isEmpty() {
      return root.isEmpty();
   }

   @Override
   public int height() {

      int height = -1;
      BSTNode<T> aux1 = root;
      BSTNode<T> aux2 = root;
      while (!aux1.isEmpty() || !aux2.isEmpty()) {
         height++;
         aux1 = (BSTNode<T>) aux1.getLeft();
         aux2 = (BSTNode<T>) aux2.getRight();

      }
      return height;
   }

   @Override
   public BSTNode<T> search(T element) {
      return searchRecursiveForBST(root, element);
   }

   private BSTNode<T> searchRecursiveForBST(BSTNode<T> root2, T element) {

      if (root2.isEmpty() || root2.getData().equals(element)) {
         return root2;
      }
      if (root.getData().compareTo(element) > 0) {
         BSTNode aux = (BSTNode) root2.getLeft();
         return searchRecursiveForBST(aux, element);
      } else {
         BSTNode aux = (BSTNode) root2.getRight();
         return searchRecursiveForBST(aux, element);
      }
   }

   @Override
   public void insert(T element) {
      treeInsert(root, element);
   }

   private void treeInsert(BSTNode<T> raiz, T element) {
      if (raiz.isEmpty()) {
         BSTNode nodeRight = new BSTNode<>();
         BSTNode nodeLeft = new BSTNode<>();
         raiz.setData(element);
         raiz.setLeft(nodeLeft);
         raiz.setRight(nodeRight);
      } else if (raiz.getData().compareTo(element) < 0) {
         BSTNode aux = (BSTNode) raiz.getRight();
         treeInsert(aux, element);
         aux.setParent(raiz);
      } else if (raiz.getData().compareTo(element) > 0) {
         BSTNode aux = (BSTNode) raiz.getLeft();
         treeInsert(aux, element);
         aux.setParent(raiz);
      }

   }

   @Override
   public BSTNode<T> maximum() {
      if (root.isEmpty()) {
         return null;
      }
      return treeMaximum(root);
   }

   private BSTNode<T> treeMaximum(BSTNode node) {
      if (node.getRight().isEmpty()) {
         return node;
      }
      return treeMaximum((BSTNode) node.getRight());
   }

   @Override
   public BSTNode<T> minimum() {
      if (root.isEmpty()) {
         return null;
      }
      return treeMinimum(root);
   }

   private BSTNode<T> treeMinimum(BSTNode node) {
      if (node.getLeft().isEmpty()) {
         return node;
      }
      return treeMinimum((BSTNode) node.getLeft());
   }

   @Override
   public BSTNode<T> sucessor(T element) {
      BSTNode node = search(element);

      if (!node.getRight().isEmpty()) {
         return treeMinimum(node);
      }
      BSTNode aux = (BSTNode) node.getParent();
      while (!aux.isEmpty() && node == aux.getRight()) {
         node = aux;
         aux = (BSTNode) aux.getParent();
      }
      return aux;

   }

   @Override
   public BSTNode<T> predecessor(T element) {
      BSTNode node = search(element);

      if (!node.getLeft().isEmpty()) {
         return treeMaximum(node);
      }
      BSTNode aux = (BSTNode) node.getParent();
      while (!aux.isEmpty() && node == aux.getLeft()) {
         node = aux;
         aux = (BSTNode) aux.getParent();
      }
      return aux;
   }

   @SuppressWarnings("unchecked")
   @Override
   public void remove(T element) {
      // procura o no a ser removido 
      BSTNode node = search(element);

      if (!node.isEmpty()) {
         if (node.isLeaf()) {
            node = new BSTNode<>();
         }
         // se o no a ser removido tem apenas um filho
         else if ((!node.getRight().isEmpty() && node.getLeft().isEmpty())
               || (node.getRight().isEmpty() && !node.getLeft().isEmpty())) {
            if (node != root) {
               if (node == (BSTNode) root.getLeft()) {
                  if (!node.getLeft().isEmpty()) {
                     node.getLeft().setParent(node.getParent());
                     node.getParent().setLeft(node.getLeft());
                  } else {
                     node.getRight().setParent(node.getParent());
                     node.getParent().setLeft(node.getRight());
                  }
               } else { // se o no for o filho da direita
                  if (!node.getLeft().isEmpty()) {
                     node.getLeft().setParent(node.getParent());
                     node.getParent().setRight(node.getLeft());
                  } else {
                     node.getRight().setParent(node.getParent());
                     node.getParent().setRight(node.getRight());
                  }
               }
            } else {
               if (!node.getLeft().isEmpty()) {
                  root = (BSTNode<T>) node.getLeft();
               } else {
                  root = (BSTNode<T>) node.getRight();
               }

            }
         } // se tiver dois filhos
         else {

            BSTNode sucessor = sucessor(element);
            node.setData(sucessor.getData());
            if (element instanceof Integer) {
               element = (T) sucessor.getData();
            }

            remove(element);
         }
      }
   }

   @Override
   public T[] preOrder() {
      T[] array = (T[]) new Comparable[size()];
      String result = "";
      result = genericsPreOrder(root);
      return null;
   }

   private String genericsPreOrder(BSTNode<T> node) {
      if (node.isEmpty()) {
         return null;
      }

      System.out.print(node.getData() + " ");

      genericsPreOrder((BSTNode<T>) node.getLeft());

      genericsPreOrder((BSTNode<T>) node.getRight());

      return null;

   }

   @Override
   public T[] order() {
      T[] array = (T[]) new Comparable[size()];
      String result = "";
      result = genericsOrder(root);
      return null;
   }

   private String genericsOrder(BSTNode<T> node) {
      if (node.isEmpty()) {
         return null;
      }

      genericsOrder((BSTNode<T>) node.getLeft());

      System.out.print(node.getData() + " ");

      genericsOrder((BSTNode<T>) node.getRight());

      return null;
   }

   @Override
   public T[] postOrder() {
      T[] array = (T[]) new Comparable[size()];
      String result = "";
      result = genericsPostOrder(root);
      return null;
   }

   private String genericsPostOrder(BSTNode<T> node) {
      if (node.isEmpty()) {
         return null;
      }

      genericsPostOrder((BSTNode<T>) node.getLeft());

      genericsPostOrder((BSTNode<T>) node.getRight());

      System.out.print(node.getData() + " ");

      return null;
   }

   /**
    * This method is already implemented using recursion. You must understand
    * how it work and use similar idea with the other methods.
    */
   @Override
   public int size() {
      return size(root);
   }

   private int size(BSTNode<T> node) {
      int result = 0;
      // base case means doing nothing (return 0)
      if (!node.isEmpty()) { // indusctive case
         result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
      }
      return result;
   }

}
